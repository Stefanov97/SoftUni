public class Main {
    public static void main(String[] args) {
        RandomArrayList list = new RandomArrayList();

        list.add("Orlando");
        list.add("Orlandovci");
        list.add(12);
        list.add(65.259213);

        System.out.println(list.getRandomElement());
        System.out.println(list.getRandomElement());
        System.out.println(list.getRandomElement());

    }
}
