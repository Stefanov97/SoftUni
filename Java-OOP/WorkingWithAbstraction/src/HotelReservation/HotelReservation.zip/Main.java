package HotelReservation;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] tokens = scanner.nextLine().split("\\s+");
        double pricePerDay = Double.parseDouble(tokens[0]);
        int numberOfDays = Integer.parseInt(tokens[1]);
        String seasonName = tokens[2].toUpperCase();
        String discountName = tokens[3].toUpperCase();
        Season season = getSeason(seasonName);
        Discount discount = getDiscount(discountName);


        PriceCalculator calculator = new PriceCalculator(pricePerDay, numberOfDays, season, discount);
        System.out.printf("%.2f", calculator.calculate());


    }

    private static Discount getDiscount(String discountName) {
        Discount discount = Discount.SECOND_VISIT;
        switch (discountName) {
            case "VIP":
                discount = Discount.VIP;
                break;
            case "NONE":
                discount = Discount.NONE;
                break;
        }
        return discount;
    }

    private static Season getSeason(String seasonName) {
        Season season = Season.WINTER;
        switch (seasonName) {
            case "AUTUMN":
                season = Season.AUTUMN;
                break;
            case "SUMMER":
                season = Season.SUMMER;
                break;
            case "Spring":
                season = Season.SPRING;
                break;

        }
        return season;
    }
}
