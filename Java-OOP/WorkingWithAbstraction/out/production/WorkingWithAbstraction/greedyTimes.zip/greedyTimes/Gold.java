package greedyTimes;

public class Gold {
    private long quantity;

    public Gold(long quantity) {
        this.quantity = quantity;
    }

    public long getQuantity() {
        return this.quantity;
    }

    public void addQuantity(int value) {
        this.quantity += value;
    }
}
