package TrafficLights;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] tokens = scanner.nextLine().split("\\s+");
        int n = Integer.parseInt(scanner.nextLine());
        TrafficLights[] lights = new TrafficLights[tokens.length];
        while (n-- > 0) {
            for (int i = 0; i < tokens.length; i++) {
                String name = tokens[i];
                TrafficLights currentLight = TrafficLights.valueOf(name);
                if (currentLight.equals(TrafficLights.YELLOW)) {
                    currentLight = TrafficLights.RED;
                } else if (currentLight.equals(TrafficLights.RED)) {
                    currentLight = TrafficLights.GREEN;
                } else {
                    currentLight = TrafficLights.YELLOW;
                }
                lights[i] = currentLight;
            }
            int index=0;
            StringBuilder sb = new StringBuilder();
            for (TrafficLights light : lights) {
                sb.append(light+" ");
                tokens[index++] = String.valueOf(light);
            }

            System.out.println(sb.toString());

        }
    }
}
