package TrafficLights;

public enum TrafficLights {
    RED,
    GREEN,
    YELLOW;
}
