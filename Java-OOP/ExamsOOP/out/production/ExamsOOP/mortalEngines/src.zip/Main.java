import core.MachineFactoryImpl;
import core.MachinesManagerImpl;

import core.PilotFactoryImpl;
import core.interfaces.MachineFactory;
import core.interfaces.PilotFactory;
import core.interfaces.MachinesManager;
import entities.interfaces.Machine;
import entities.interfaces.Pilot;


import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        PilotFactory pilotFactory = new PilotFactoryImpl();
        MachineFactory machineFactory = new MachineFactoryImpl();
        Map<String, Pilot> pilots = new LinkedHashMap<>();
        Map<String, Machine> machines = new LinkedHashMap<>();

        MachinesManager machinesManager = new MachinesManagerImpl(pilotFactory, machineFactory, pilots, machines);

       Scanner scanner = new Scanner(System.in);
       String line = scanner.nextLine();
       while (!"Over".equals(line)){
           String[] tokens = line.split("\\s+");
           String command = tokens[0];
           String name = tokens[1];
           switch (command) {
               case "Hire":
                   System.out.println(machinesManager.hirePilot(name));
                   break;
               case "Report":
                   System.out.println(machinesManager.pilotReport(name));
                   break;

               case "ManufactureTank": {
                   double attackPoints = Double.parseDouble(tokens[2]);
                   double defensePoints = Double.parseDouble(tokens[3]);
                   System.out.println(machinesManager.manufactureTank(name, attackPoints, defensePoints));
                   break;
               }
               case "ManufactureFighter":
                   double attackPoints = Double.parseDouble(tokens[2]);
                   double defensePoints = Double.parseDouble(tokens[3]);
                   System.out.println(machinesManager.manufactureFighter(name, attackPoints, defensePoints));
                   break;

               case "Engage":
                String machineName = tokens[2];
                   System.out.println(machinesManager.engageMachine(name, machineName));
                   break;

               case "Attack":
                   String defendingMachineName = tokens[2];
                   System.out.println(machinesManager.attackMachines(name, defendingMachineName));
                   break;

               case "DefenseMode":
                   System.out.println(machinesManager.toggleTankDefenseMode(name));
                   break;

               case "AggressiveMode":
                   System.out.println(machinesManager.toggleFighterAggressiveMode(name));
                   break;
           }

           line = scanner.nextLine();
       }

    }
}
