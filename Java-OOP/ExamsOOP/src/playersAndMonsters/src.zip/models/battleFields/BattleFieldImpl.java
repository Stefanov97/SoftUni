package models.battleFields;

import models.battleFields.interfaces.Battlefield;
import models.cards.interfaces.Card;
import models.players.interfaces.Player;
import repositories.interfaces.CardRepository;

import java.util.List;

public class BattleFieldImpl implements Battlefield {

    @Override
    public void fight(Player attackPlayer, Player enemyPlayer) {
        if(attackPlayer.isDead() || enemyPlayer.isDead()){
            throw new IllegalArgumentException("Player is dead!");
        }
        if(attackPlayer.getClass().getSimpleName().equals("Beginner")){
            attackPlayer.setHealth(attackPlayer.getHealth() + 40);
            CardRepository cardRepository = attackPlayer.getCardRepository();
            for (Card card : cardRepository.getCards()) {
                card.setDamagePoints(card.getDamagePoints() + 30);
            }

        }

        if(enemyPlayer.getClass().getSimpleName().equals("Beginner")){
            enemyPlayer.setHealth(enemyPlayer.getHealth() + 40);
            CardRepository cardRepository = enemyPlayer.getCardRepository();
            for (Card card : cardRepository.getCards()) {
                card.setDamagePoints(card.getDamagePoints() + 30);
            }

        }

        CardRepository attackerRepo = attackPlayer.getCardRepository();
        for (Card card : attackerRepo.getCards()) {
            attackPlayer.setHealth(attackPlayer.getHealth() + card.getHealthPoints());
        }

        CardRepository enemyRepo = enemyPlayer.getCardRepository();
        for (Card card : enemyRepo.getCards()) {
            enemyPlayer.setHealth(enemyPlayer.getHealth() + card.getHealthPoints());
        }

        while (!attackPlayer.isDead() && !enemyPlayer.isDead()){
            List<Card> attackerCards = attackerRepo.getCards();
            for (Card card : attackerCards) {
                enemyPlayer.takeDamage(card.getDamagePoints());
            }
            if(enemyPlayer.isDead()){
                break;
            }

            List<Card> enemyCards = enemyRepo.getCards();
            for (Card enemyCard : enemyCards) {
                attackPlayer.takeDamage(enemyCard.getDamagePoints());
            }

        }

    }
}
