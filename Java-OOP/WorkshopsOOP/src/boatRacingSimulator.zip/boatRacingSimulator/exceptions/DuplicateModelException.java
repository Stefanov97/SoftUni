package boatRacingSimulator.exceptions;

public class DuplicateModelException extends Exception {
}
