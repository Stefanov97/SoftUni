package boatRacingSimulator.interfaces;

import boatRacingSimulator.models.races.Race;

public interface Outputable {
    double getOutput(Race race);
}
