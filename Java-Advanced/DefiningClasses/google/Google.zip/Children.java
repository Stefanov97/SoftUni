public class Children {
    private String childName;
    private String childBirthday;

    public Children(String childrenName,String childrenBirthday){
        this.childName=childrenName;
        this.childBirthday=childrenBirthday;
    }

    public String getChildName() {
        return childName;
    }

    public String getChildBirthday() {
        return childBirthday;
    }
}
