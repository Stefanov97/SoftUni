public class SiameseCat {
    private String name;
    private double earSize;
    public SiameseCat(String name,double earSize){
        this.name=name;
        this.earSize=earSize;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getEarSize() {
        return earSize;
    }

    public void setEarSize(double earSize) {
        this.earSize = earSize;
    }
}
