public class Main {
    public static void main(String[] args) {
        Integer[] arr= ArrayCreator.create(Integer.class,10,0);
        System.out.println();
    }
}
