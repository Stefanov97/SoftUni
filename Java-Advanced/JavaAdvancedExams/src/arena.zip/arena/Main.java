package arena;
public class Main{
    public static void main(String[] args) {
        //Creates fightingArena
        FightingArena fightingArena = new FightingArena("Armeec");

//Creates stats
        Stat firstGlariatorStat = new Stat(20, 25, 35, 14, 48);
        Stat secondGlariatorStat = new Stat(40, 60, 70, 50, 80);
        Stat thirdGlariatorStat = new Stat(20, 25, 35, 14, 48);

//Creates weapons
        Weapon firstGlariatorWeapon = new Weapon(5, 28, 100);
        Weapon secondGlariatorWeapon = new Weapon(5, 28, 100);
        Weapon thirdGlariatorWeapon = new Weapon(50, 50, 50);

//Creates gladiators
        Gladiator firstGladiator = new Gladiator("Stoyan", firstGlariatorStat, firstGlariatorWeapon);
        Gladiator secondGladiator = new Gladiator("Pesho", secondGlariatorStat, secondGlariatorWeapon);
        Gladiator thirdGladiator = new Gladiator("Author", thirdGlariatorStat, thirdGlariatorWeapon);

//Adds gladiators to fightingArena
        fightingArena.add(firstGladiator);
        fightingArena.add(secondGladiator);
        fightingArena.add(thirdGladiator);


        System.out.println(fightingArena.getGladiatorWithHighestStatPower());
       

    }
}